# TEK-PLYTA

MES płyt żelbetowych wg PN-EN 1992-1-1:2008 + NA. Linia programów obliczeniowych TEKTORIA.
Specyfikacja v1: dokument „TEK-PLYTA v1 — specyfikacja” (Claude Docs).

## Uruchomienie testów

Wymaga Node.js 22+. W folderze projektu:

```
npm test
```

## Struktura

| Plik | Co robi |
| --- | --- |
| `src/dkt.js` | element DKT (Batoz, Bathe, Ho 1980) — główny: macierz sztywności, momenty |
| `src/mitc3.js` | element MITC3 (Lee, Bathe 2004), Mindlin — kontrolny, płyty grube |
| `src/supports.js` | sztywności sprężyn słupów i ścian |
| `src/model.js` | składanie modelu, warunki brzegowe, reakcje, momenty w węzłach |
| `src/solver.js` | rozkład Cholesky'ego w zapisie profilowym (skyline) |
| `src/ordering.js` | numeracja węzłów RCM (mały profil macierzy) |
| `bench/` | pomiary wydajności (`node bench/strop-30x60.mjs`) |
| `src/mesh.js` | siatki strukturalne do testów wzorcowych |
| `tests/` | testy T1–T5, MITC3, sprężyny (21 testów) |

## Stan (2026-10-27)

| Test | Wynik |
| --- | --- |
| Konwencja znaków, ruchy sztywne, symetria K | zaliczone |
| T1 równowaga | suma reakcji = suma obciążeń (błąd < 1e-9) |
| T2 zbieżność i symetria | zaliczone |
| T3 płyta swobodnie podparta, siatka 32×32 | w = 0,00406, M = 0,0479 (Timoshenko: 0,00406 / 0,0479) |
| T4 płyta utwierdzona, siatka 32×32 | w = 0,00127, M = 0,0230, Mkr = −0,0513 (0,00126 / 0,0231 / −0,0513) |
| T5 NAFEMS LE6, siatka 64×64 | σ1 = 0,809 MPa (cel 0,802; +0,9 %) |
| MITC3 płyta cienka t/a = 0,001 | w = Kirchhoff (brak blokady ścinania) |
| MITC3 płyta gruba t/a = 0,1 | w = 0,004265 (Wang: 0,004273) |
| Sprężyny: 4 narożniki, przypadki graniczne k → 0 i k → ∞ | zgodne z wynikami ścisłymi |
| T6 Morley 30°, L/h = 1000, siatka 64×64 | w = 0,4146, M1 = 1,927, M2 = 1,111 (wzorzec 0,4134 / 1,922 / 1,106) |
| T6 Razzaque 60°, siatka 32×32 | w = 0,7907, My = 0,9597 (wzorzec 0,7912 / 0,9601) |

Obserwacja z T5: przy podparciu „twardym” (w = 0 i dw/dt = 0) zbieżność w narożach
rozwartych jest wolna (−6 % przy 64×64) — osobliwość narożna. Wniosek: zagęszczanie
siatki w narożach rozwartych i przy słupach.

## Do zrobienia w etapie 2

- [x] Element Mindlina — MITC3 jako kontrolny (DKMT odrzucony, patrz specyfikacja sekcja 4)
- [x] Sprężyny podporowe (węzłowe) — słupy w jednym węźle; rozłożenie na obrys słupa w etapie 3
- [x] T6: płyty skośne Morleya i Razzaque'a — zgodność ≤ 0,1 % przy 96×96 (Grbac, Ribarić 2022)
- [x] Numeracja RCM; model dwufazowy: jeden rozkład K, wiele przypadków obciążeń
- [ ] Solver rzadki (nested dissection) — odłożony; decyzja po pilotażu na realnych stropach
- [ ] Web Worker

Obserwacje z MITC3: moment utwierdzenia niedoszacowany o 7 % przy 64×64 (moment stały
w elemencie); siły poprzeczne przy podporach niezbieżne (warstwa brzegowa Mindlina).
Stąd decyzje: DKT głównym elementem, VEd do przebicia z reakcji podpór.

## Wydajność (strop 30 × 60 m, węzły w losowej kolejności, Node 22)

| Oczko | Niewiadome | Budowa + rozkład | Przypadek obciążenia | Pamięć |
| --- | --- | --- | --- | --- |
| 0,5 m | 22 tys. | 1,0 s | 0,17 s | 84 MB |
| 0,35 m | 44 tys. | 3,7 s | 0,39 s | 143 MB |
| 0,25 m | 87 tys. | 13,5 s | 0,84 s | 341 MB |

Bez RCM siatka 1 m: 87 MB i 25 s; z RCM: 5 MB i 0,3 s. Wniosek: siatka zagęszczana
(gęsto przy słupach i w narożach, oczko ~0,5 m w polach) zamiast jednolitej 0,25 m.
