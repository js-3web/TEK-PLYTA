// Odwrócony algorytm Cuthilla–McKee (RCM): numeracja węzłów, która skupia
// niezerowe wyrazy macierzy sztywności blisko przekątnej (mały profil).
// E. Cuthill, J. McKee (1969); A. George, J. Liu, "Computer Solution of Large
// Sparse Positive Definite Systems", Prentice-Hall 1981 (węzeł pseudo-peryferyjny).
//
// Idea na budowlanym przykładzie: numerujemy węzły "warstwami" od jednego końca
// płyty jak fronty robót — sąsiedzi mają bliskie numery, więc w macierzy leżą
// blisko przekątnej. Odwrócenie kolejności (Reverse) dodatkowo zmniejsza wypełnienie.

export function adjacency(nNodes, elems) {
  const sets = Array.from({ length: nNodes }, () => new Set());
  for (const e of elems) for (const a of e) for (const b of e) if (a !== b) sets[a].add(b);
  return sets.map(s => [...s]);
}

// Przeszukiwanie wszerz: struktura poziomów od węzła start (tylko w obrębie jego składowej)
function levels(adj, start) {
  const lev = new Map([[start, 0]]);
  let front = [start], depth = 0, last = [start];
  while (front.length) {
    const next = [];
    for (const v of front) for (const u of adj[v]) if (!lev.has(u)) { lev.set(u, depth + 1); next.push(u); }
    if (next.length) { last = next; depth++; }
    front = next;
  }
  return { depth, last, lev };
}

// Węzeł pseudo-peryferyjny: "najdalszy" węzeł składowej (George–Liu)
function pseudoPeripheral(adj, start) {
  let v = start, { depth, last } = levels(adj, v);
  for (;;) {
    const u = last.reduce((best, x) => (adj[x].length < adj[best].length ? x : best), last[0]);
    const L = levels(adj, u);
    if (L.depth <= depth) return v;
    v = u; depth = L.depth; last = L.last;
  }
}

// Zwraca order: order[k] = węzeł, który dostaje k-ty numer
export function rcm(nNodes, elems) {
  const adj = adjacency(nNodes, elems);
  const visited = new Uint8Array(nNodes);
  const order = [];
  for (let s = 0; s < nNodes; s++) {
    if (visited[s]) continue;
    const root = pseudoPeripheral(adj, s);
    const queue = [root]; visited[root] = 1;
    for (let h = 0; h < queue.length; h++) {
      const v = queue[h];
      const nb = adj[v].filter(u => !visited[u]).sort((p, q) => adj[p].length - adj[q].length);
      for (const u of nb) { visited[u] = 1; queue.push(u); }
    }
    order.push(...queue);
  }
  return order.reverse();
}
