// Pomiar wydajności: strop 30 x 60 m, krawędzie podparte, węzły w losowej kolejności
// (symulacja siatki z DXF). Uruchom: node bench/strop-30x60.mjs [oczka...]
import { parallelogramMesh } from '../src/mesh.js';
import { buildModel, solvePlate } from '../src/model.js';

function shuffled(mesh, seed = 1) {
  const n = mesh.nodes.length, perm = Array.from({ length: n }, (_, i) => i);
  let s = seed; const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
  for (let i = n - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [perm[i], perm[j]] = [perm[j], perm[i]]; }
  const nodes = new Array(n); perm.forEach((p, i) => { nodes[p] = mesh.nodes[i]; });
  const map = i => perm[i];
  return { nodes, elems: mesh.elems.map(e => e.map(map)), edge: Object.fromEntries(Object.entries(mesh.edge).map(([k, v]) => [k, v.map(map)])) };
}

const sizes = process.argv.slice(2).map(Number);
for (const h of sizes.length ? sizes : [1.0, 0.5, 0.35, 0.25]) {
  const m = shuffled(parallelogramMesh({ a: [60, 0], b: [0, 30], nx: Math.round(60 / h), ny: Math.round(30 / h) }));
  const fix = new Map(); for (const l of Object.values(m.edge)) for (const k of l) fix.set(k, { w: true });
  {
    const t0 = performance.now();
    const model = buildModel({ nodes: m.nodes, elems: m.elems, mat: { E: 32e6, nu: 0.2, t: 0.25 }, fix });
    const t1 = performance.now();
    for (let c = 0; c < 10; c++) model.solveCase({ q: 10 + c });
    const t2 = performance.now();
    console.log(`oczko ${h} m | niewiadome ${model.neq} | budowa+rozkład ${((t1 - t0) / 1000).toFixed(1)} s | 1 przypadek ${((t2 - t1) / 10000).toFixed(2)} s | pamięć ${(process.memoryUsage().heapUsed / 1e6 + process.memoryUsage().arrayBuffers / 1e6).toFixed(0)} MB`);
  }
  for (const ordering of ['none']) {
    if (ordering === 'none' && h < 0.9) continue; // bez RCM duże siatki nie mieszczą się w pamięci
    const t0 = performance.now();
    const r = solvePlate({ nodes: m.nodes, elems: m.elems, mat: { E: 32e6, nu: 0.2, t: 0.25 }, q: 10, fix, ordering });
    const dt = (performance.now() - t0) / 1000;
    console.log(`oczko ${h} m | niewiadome ${r.neq} | ${ordering.padEnd(4)} | profil ${(r.profileSize * 8 / 1e6).toFixed(0)} MB | czas ${dt.toFixed(1)} s`);
  }
}
